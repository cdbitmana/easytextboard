package com.sbs.example.easytextboard.controller;

public abstract class Controller {

	public abstract void doCommand(String command);

}
