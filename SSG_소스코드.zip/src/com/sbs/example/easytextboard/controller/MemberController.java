package com.sbs.example.easytextboard.controller;

import java.util.Scanner;

import com.sbs.example.easytextboard.container.*;
import com.sbs.example.easytextboard.dto.*;
import com.sbs.example.easytextboard.service.*;

public class MemberController extends Controller {

	private MemberService memberService;
	private Scanner sc;

	public MemberController() {
		sc = Container.scanner;
		memberService = Container.memberService;
	}

	public void doCommand(String command) {

		if (command.equals("member join")) {
			doJoin();
		} else if (command.equals("member login")) {
			doLogin();
		} else if (command.equals("member logout")) {
			doLogout();
		} else if (command.equals("member modify")) {
			doModify();
		} else if (command.equals("member whoami")) {
			showWhoami();
		} else {
			System.out.println("존재하지 않는 명령어");
		}

	}

	// showWhoami
	private void showWhoami() {
		if (!Container.session.isLogined()) {
			System.out.println("로그인 후 이용해 주세요.");
			return;
		}

		Member member = memberService.getLoginedMember();

		int id = member.getId();
		String loginId = member.getLoginId();
		String name = member.getName();

		System.out.printf("회원번호 : %d\n", id);
		System.out.printf("아이디 : %s\n", loginId);
		System.out.printf("이름 : %s\n", name);

	}

	// doModify
	private void doModify() {
		if (!Container.session.isLogined()) {
			System.out.println("로그인 후 이용해 주세요.");
			return;
		}

		System.out.println("회원이름 수정");
		System.out.printf("새 이름 : ");
		String newName = sc.nextLine();
		memberService.doModify(Container.session.getLoginedId(), newName);
		System.out.println("회원 정보가 수정되었습니다.");

	}

	// doLogout
	private void doLogout() {
		if (Container.session.isLogined()) {
			System.out.println("로그아웃 되었습니다.");
			Container.session.setLoginedId(0);
		} else if (!Container.session.isLogined()) {
			System.out.println("이미 로그아웃 상태입니다.");
		}

	}

	// doJoin
	private void doJoin() {

		if (Container.session.isLogined()) {
			System.out.println("로그아웃 후 이용해 주세요.");
			return;
		}

		System.out.printf("아이디 : ");
		String loginId = sc.nextLine().trim();

		Member member = memberService.getMemberByLoginId(loginId);

		if (member != null) {
			System.out.println("이미 존재하는 아이디입니다.");
			return;
		}

		System.out.printf("비밀번호 : ");
		String pw = sc.nextLine().trim();

		System.out.printf("이름 : ");
		String name = sc.nextLine().trim();

		int id = memberService.doJoin(loginId, pw, name);

		System.out.printf("%d번 회원으로 가입되었습니다.\n", id);

	}

	// doLogin
	private void doLogin() {
		if (Container.session.isLogined()) {
			System.out.println("이미 로그인 상태입니다.");
			return;
		}

		System.out.printf("아이디 : ");
		String loginId = sc.nextLine().trim();

		Member member = memberService.getMemberByLoginId(loginId);

		if (member == null) {
			System.out.println("일치하는 아이디가 없습니다.");
			return;
		}

		System.out.printf("비밀번호 : ");
		String loginPw = sc.nextLine().trim();

		if (!member.getLoginPw().equals(loginPw)) {
			System.out.println("비밀번호가 맞지 않습니다.");
			return;
		}

		System.out.printf("%d번 회원으로 로그인 되었습니다.\n", member.getId());
		Container.session.setLoginedId(member.getId());

	}

}
