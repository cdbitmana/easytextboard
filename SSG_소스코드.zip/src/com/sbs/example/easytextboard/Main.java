package com.sbs.example.easytextboard;

public class Main {

	public static void main(String[] args) {

		new App().run();

	}

}
